#pragma once

#include "hw_m1/hw1/2d/render_object2d/diamond/diamond.h"
#include "hw_m1/hw1/2d/render_object2d/star/star.h"
#include "hw_m1/hw1/2d/render_object2d/square/square.h"
#include "hw_m1/hw1/2d/render_object2d/hexagon/hexagon.h"
