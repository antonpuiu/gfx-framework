#include "hw_m1/hw2/3d/transform3d.h"

#include <iostream>
#include <stdexcept>

using namespace m1;

Transform3D::Transform3D()
    : Transform3D(nullptr)
{
}

Transform3D::Transform3D(Transform3D* parent)
    : parent(parent)
    , modelMatrix(glm::mat3(1))
    , scale({ 1.f, 1.f, 1.f })
    , pos({ 0, 0, 0 })
    , rotation({ 0, 0, 0 })
    , dirtyFlag(true)
    , detatched(false)
{
}

Transform3D::Transform3D(Transform3D& transform2D)
    : parent(transform2D.parent)
    , modelMatrix(transform2D.modelMatrix)
    , scale(transform2D.scale)
    , pos(transform2D.pos)
    , rotation(transform2D.rotation)
    , scaleDetatched(transform2D.scaleDetatched)
    , posDetatched(transform2D.posDetatched)
    , rotationDetatched(transform2D.rotationDetatched)
    , dirtyFlag(transform2D.dirtyFlag)
    , detatched(transform2D.detatched)
{
}

glm::mat4 Transform3D::GetModelMatrix()
{
    if (dirtyFlag)
        ComputeModelMatrix();

    return modelMatrix;
}

void Transform3D::ComputeModelMatrix()
{
    glm::mat4 rot;
    glm::mat4 trs;
    glm::mat4 scl;

    if (detatched) {
        rot = glm::rotate(glm::mat4(1.f), glm::radians(rotationDetatched.y),
                          glm::vec3(0.f, 1.f, 0.f)) *
              glm::rotate(glm::mat4(1.f), glm::radians(rotationDetatched.x),
                          glm::vec3(1.f, 0.f, 0.f)) *
              glm::rotate(glm::mat4(1.f), glm::radians(rotationDetatched.z),
                          glm::vec3(0.f, 0.f, 1.f));
        trs = glm::translate(glm::mat4(1.f), posDetatched);
        scl = glm::scale(glm::mat4(1.f), scaleDetatched);
    } else {
        rot = glm::rotate(glm::mat4(1.f), glm::radians(rotation.y), glm::vec3(0.f, 1.f, 0.f)) *
              glm::rotate(glm::mat4(1.f), glm::radians(rotation.x), glm::vec3(1.f, 0.f, 0.f)) *
              glm::rotate(glm::mat4(1.f), glm::radians(rotation.z), glm::vec3(0.f, 0.f, 1.f));
        trs = glm::translate(glm::mat4(1.f), pos);
        scl = glm::scale(glm::mat4(1.f), scale);
    }

    if (parent != nullptr && !detatched) {
        modelMatrix = parent->modelMatrix * trs * rot * scl;
    } else {
        modelMatrix = trs * rot * scl;
    }

    for (Transform3D* children : childrens)
        children->ComputeModelMatrix();

    dirtyFlag = false;
}

void Transform3D::SetPosition(glm::vec3 pos)
{
    if (detatched)
        posDetatched = pos;
    else
        this->pos = pos;

    dirtyFlag = true;
}

void Transform3D::AddPosition(glm::vec3 qty)
{
    if (detatched)
        posDetatched += qty;
    else
        pos += qty;

    dirtyFlag = true;
}

glm::vec3 Transform3D::GetPosition()
{
    if (detatched)
        return posDetatched;

    return pos;
}

glm::vec3 Transform3D::GetGlobalPosition()
{
    if (detatched)
        return posDetatched;

    if (!parent)
        return pos;

    auto prt = parent;
    glm::vec3 result = pos;

    while (prt != nullptr) {
        result += prt->GetPosition();
        prt = prt->parent;
    }

    return result;
}

void Transform3D::SetScale(glm::vec3 scale)
{
    if (detatched)
        scaleDetatched = scale;
    else
        this->scale = scale;

    dirtyFlag = true;
}

void Transform3D::AddScale(glm::vec3 qty)
{
    if (detatched)
        scaleDetatched += qty;
    else
        scale += qty;

    dirtyFlag = true;
}

glm::vec3 Transform3D::GetScale()
{
    if (detatched)
        return scaleDetatched;

    return scale;
}

glm::vec3 Transform3D::GetGlobalScale()
{
    if (detatched)
        return scaleDetatched;

    if (!parent)
        return scale;

    auto prt = parent;
    glm::vec3 result = scale;

    while (prt != nullptr) {
        result *= prt->GetScale();
        prt = prt->parent;
    }

    return result;
}

void Transform3D::SetRotation(glm::vec3 rotation)
{
    if (detatched)
        rotationDetatched = rotation;
    else
        this->rotation = rotation;

    dirtyFlag = true;
}

void Transform3D::AddRotation(glm::vec3 qty)
{
    if (detatched)
        rotationDetatched += qty;
    else
        rotation += qty;

    dirtyFlag = true;
}

glm::vec3 Transform3D::GetRotation()
{
    if (detatched)
        return rotationDetatched;

    return rotation;
}

glm::vec3 Transform3D::GetGlobalRotation()
{
    if (detatched)
        return rotationDetatched;

    if (!parent)
        return rotation;

    auto prt = parent;
    glm::vec3 result = rotation;

    while (prt != nullptr) {
        result += prt->GetRotation();
        prt = prt->parent;
    }

    return result;
}

void Transform3D::AddChildren(Transform3D* children)
{
    if (children == nullptr)
        throw std::runtime_error("Cannot insert null children.");

    children->parent = this;

    bool insert = true;

    for (auto child : childrens) {
        if (children == child) {
            insert = false;
            break;
        }
    }

    if (insert)
        childrens.push_back(children);
}

void Transform3D::AttatchToParent(Transform3D* parent)
{
    this->parent = parent;
    parent->childrens.push_back(this);
    detatched = false;
    dirtyFlag = true;
}

void Transform3D::DetatchFromParent()
{
    for (auto it = parent->childrens.begin(); it != parent->childrens.end(); it++) {
        if (*it == this) {
            parent->childrens.erase(it);
            break;
        }
    }

    auto prt = parent;

    posDetatched = pos;
    scaleDetatched = prt->GetScale() + scale;
    rotationDetatched = rotation;

    while (prt != nullptr) {
        posDetatched += prt->GetPosition();
        rotationDetatched += prt->GetRotation();
        prt = prt->parent;
    }

    detatched = true;
    dirtyFlag = true;
    parent = nullptr;
}
