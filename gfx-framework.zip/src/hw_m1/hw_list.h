#pragma once

#include "hw_m1/hw1/hw1.h"
#include "hw_m1/hw2/hw2.h"
